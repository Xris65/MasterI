#include "EdgeConResolution.h"
#include "Graph.h"
#include <stdlib.h>
#include <stdio.h>

int BruteForceEdgeCon(EdgeConGraph graph)
{
    return -1;
}
