#include "formalism.h"
#include "limits.h"

/*
TODO
*/
bool NextPermutation(int *P, unsigned int n);