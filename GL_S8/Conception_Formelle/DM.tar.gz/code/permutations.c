#include "permutations.h"

void initPerm(int *P, unsigned int n)
{
    // TODO
    return;
}

bool isMaxPerm(int *P, unsigned int n)
{
    // TODO
    return true;
}